package org.zyad.mediaclient.Mapper;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;
import org.xproce.lab.Creator;
import org.zyad.mediaclient.Dto.CreatorDto;


@Component
public class CreatorMapper {
    private ModelMapper modelMapper = new ModelMapper();

    public Creator fromCreatorDtoToCreator(CreatorDto creatorDto){
        return this.modelMapper.map(creatorDto,Creator.class);
    }
    public CreatorDto fromCreatorToCreatorDto(Creator creator){
        return this.modelMapper.map(creator,CreatorDto.class);
    }
}
