package org.zyad.mediaclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MediaclientApplication {

    public static void main(String[] args) {
        SpringApplication.run(MediaclientApplication.class, args);
    }

}
