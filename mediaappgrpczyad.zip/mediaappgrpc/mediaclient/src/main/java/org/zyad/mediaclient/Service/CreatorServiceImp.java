package org.zyad.mediaclient.Service;


import net.devh.boot.grpc.client.inject.GrpcClient;
import org.xproce.lab.Creator;
import org.xproce.lab.CreatorIdRequest;
import org.xproce.lab.CreatorServiceGrpc;
import org.xproce.lab.VideoStream;
import org.zyad.mediaclient.Dto.CreatorDto;

public class CreatorServiceImp{
    @GrpcClient("mediaserver")
    CreatorServiceGrpc.CreatorServiceBlockingStub stub;

    public Creator getCreatorById(CreatorIdRequest creatorIdRequest) {
        return stub.getCreator(creatorIdRequest);
    }


    public VideoStream getCreatorVideo(CreatorIdRequest creatorIdRequest) {
        return stub.getCreatorVideos(creatorIdRequest);
    }
}
