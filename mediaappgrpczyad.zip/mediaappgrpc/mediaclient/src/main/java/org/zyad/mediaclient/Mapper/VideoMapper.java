package org.zyad.mediaclient.Mapper;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;
import org.xproce.lab.Video;
import org.zyad.mediaclient.Dto.VideoDto;

@Component
public class VideoMapper {
    private ModelMapper modelMapper = new ModelMapper();

    public Video fromVideoDtoToVideo(VideoDto videoDto){
        return this.modelMapper.map(videoDto, Video.class);
    }
    public VideoDto fromVideoToVideoDto(Video video){
        return  this.modelMapper.map(video,VideoDto.class);
    }
}
