package org.zyad.mediaclient.Dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class VideoDto {
    private String name;
    private String url;
    private String desc;
    private String creator;
}
