package org.zyad.mediaclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaclientApplicationTests {

    @Test
    void contextLoads() {
    }

}
